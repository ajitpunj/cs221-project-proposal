clear variables; clc;

features = csvread('five_airlines_features.csv');
cancels = csvread('five_airlines_cancels.csv'); 
index_not_nan = not(isnan(cancels));

features = features(index_not_nan, :);
cancels = cancels(index_not_nan);

m = size(features, 1);
n = size(features, 2);

fraction = 4999;

rng(1);
rand_ind = randperm(m);
features = features(rand_ind, :);
cancels = cancels(rand_ind);

new_m = floor(size(features, 1) / m) * fraction;
n = size(features, 2);

features = features(1:new_m, :);
cancels = cancels(1:new_m);

%normalize
%features  = features ./ max(features);
%cancels = cancels ./ max(cancels);

% 80 20

% train_features = features(1 : 0.8*new_m, :);
% %dev_features = features(0.7*new_m+1 : 0.85*new_m, :);
% test_features = features(0.8*new_m+1 : new_m, :);
% 
% train_delays = delays(1 : 0.8*new_m);
% %dev_delays = delays(0.7*new_m+1 : 0.85*new_m);
% test_delays = delays(0.8*new_m+1 : new_m);

cancel_airlines = [features, cancels];

csvwrite('cancel_airlines.csv',cancel_airlines);
%csvwrite('dev_features.csv',dev_features);
%csvwrite('test_features.csv',test_features);
%csvwrite('train_delays.csv',train_delays);
%csvwrite('dev_delays.csv',dev_delays);
%csvwrite('test_delays.csv',test_delays);


