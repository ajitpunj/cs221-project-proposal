clear variables; clc;

features = csvread('five_airlines_features.csv');
delays = csvread('five_airlines_delays.csv'); 
index_not_nan = not(isnan(delays));

features = features(index_not_nan, :);
delays = delays(index_not_nan);

m = size(features, 1);
n = size(features, 2);

fraction = 4999;

rng(1);
rand_ind = randperm(m);
features = features(rand_ind, :);
delays = delays(rand_ind);

new_m = floor(size(features, 1) / m) * fraction;
n = size(features, 2);

features = features(1:new_m, :);
delays = delays(1:new_m);

new_data = (delays - mean(delays)) / std(delays);

range = (min(new_data) : 1 : max(new_data));


new_data = discretize(new_data, range);

n_classes = length(range) - 1;
y_one_hot = zeros( size( new_data, 2 ), n_classes );
for i = 1:n_classes
    rows = new_data == i;
    y_one_hot( rows, i ) = 1;
end

new_data_onehot = y_one_hot;

%normalize
%features  = features ./ max(features);
%delays = delays ./ max(delays);

% 80 20

% train_features = features(1 : 0.8*new_m, :);
% %dev_features = features(0.7*new_m+1 : 0.85*new_m, :);
% test_features = features(0.8*new_m+1 : new_m, :);
% 
% train_delays = delays(1 : 0.8*new_m);
% %dev_delays = delays(0.7*new_m+1 : 0.85*new_m);
% test_delays = delays(0.8*new_m+1 : new_m);

binned_delay_airlines = [features, new_data_onehot];

csvwrite('binned_delay_airlines.csv',binned_delay_airlines);
%csvwrite('dev_features.csv',dev_features);
%csvwrite('test_features.csv',test_features);
%csvwrite('train_delays.csv',train_delays);
%csvwrite('dev_delays.csv',dev_delays);
%csvwrite('test_delays.csv',test_delays);


