clear variables; clc;

features = csvread('five_airlines_features.csv');
delays = csvread('five_airlines_delays.csv'); 

index_not_nan = not(isnan(delays));

features = features(index_not_nan, :);
delays = delays(index_not_nan);

m = size(features, 1);
n = size(features, 2);

fraction = 1;

rng(1);
rand_ind = randperm(m);
features = features(rand_ind, :);
delays = delays(rand_ind);

new_m = floor(size(features, 1) / fraction);
n = size(features, 2);

features = features(1:new_m, :);
delays = delays(1:new_m);

%normalize
%features  = features ./ max(features);
%delays = delays ./ max(delays);

% 90 10

train_features = features(1 : 1*new_m, :);
%dev_features = features(0.7*new_m+1 : 0.85*new_m, :);
test_features = features(0.9*new_m+1 : new_m, :);

train_delays = delays(1 : 1*new_m);
%dev_delays = delays(0.7*new_m+1 : 0.85*new_m);
%test_delays = delays(0.9*new_m+1 : new_m);

csvwrite('train_features_all.csv',train_features);
%csvwrite('dev_features.csv',dev_features);
%csvwrite('test_features.csv',test_features);
csvwrite('train_delays_all.csv',train_delays);
%csvwrite('dev_delays.csv',dev_delays);
%csvwrite('test_delays.csv',test_delays);


