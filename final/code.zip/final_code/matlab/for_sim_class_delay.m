clear variables; clc;

features = csvread('five_airlines_features.csv');
delays = csvread('five_airlines_delays.csv');

index_not_nan = not(isnan(delays));

features = features(index_not_nan, :);
delays = delays(index_not_nan);

m = size(features, 1);
n = size(features, 2);

fraction = 1;

rng(1);
rand_ind = randperm(m);
features_sim_class = features(rand_ind, :);
delays = delays(rand_ind);

new_m = floor(size(features_sim_class, 1) / fraction);
n = size(features_sim_class, 2);

features_sim_class = features_sim_class(1:new_m, :);
delays = delays(1:new_m);

%normalize
features_sim_class  = features_sim_class ./ max(features_sim_class);
delays = delays ./ max(delays);



range = [-1.0, -0.75, -0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0];

res = delays;

for i = 1:length(res)
    c = res(i);
    if range(1) <= res(i) && res(i) <= range(2)
        res(i) = 0;
    elseif range(2) < res(i) && res(i) <= range(3)
        res(i) = 1;
    elseif range(3) < res(i) && res(i) <= range(4)
        res(i) = 2;
    elseif range(4) < res(i) && res(i) <= range(5)
        res(i) = 3;
    elseif range(5) < res(i) && res(i) <= range(6)
        res(i) = 4;
    elseif range(6) < res(i) && res(i) <= range(7)
        res(i) = 5;
    elseif range(7) < res(i) && res(i) <= range(8)
        res(i) = 6;
    elseif range(8) < res(i) && res(i) <= range(9)
        res(i) = 7;
    end
end


features_sim_class = [features_sim_class res];

% 70 15 15

train_features_sim_class = features_sim_class(1 : 1*new_m, :);
%dev_features_sim_class = features_sim_class(0.7*new_m+1 : 0.85*new_m, :);
%test_features_sim_class = features_sim_class(0.85*new_m+1 : new_m, :);

train_delays_sim_class = delays(1 : 1*new_m);
%dev_delays_sim_class = delays(0.7*new_m+1 : 0.85*new_m);
%test_delays_sim_class = delays(0.85*new_m+1 : new_m);

csvwrite('train_features_sim_class.csv',train_features_sim_class);
%csvwrite('dev_features_sim_class.csv',dev_features_sim_class);
%csvwrite('test_features_sim_class.csv',test_features_sim_class);
csvwrite('train_delays_sim_class.csv',train_delays_sim_class);
%csvwrite('dev_delays_sim_class.csv',dev_delays_sim_class);
%csvwrite('test_delays_sim_class.csv',test_delays_sim_class);


