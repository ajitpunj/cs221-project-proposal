clear variables; clc;

features = csvread('five_airlines_features.csv');
delays = csvread('five_airlines_delays.csv'); 

index_not_nan = not(isnan(delays));

features = features(index_not_nan, :);
delays = delays(index_not_nan);


features_sim_reg = [features delays];


% features_sim_reg = features_sim_reg((features_sim_reg(:, 7) == 1 ...
%     | features_sim_reg(:, 7) == 2) & (features_sim_reg(:, 8) == 1 ...
%     | features_sim_reg(:, 8) == 2), :);

features_sim_reg = features_sim_reg((features_sim_reg(:, 7) == 1 ...
     & features_sim_reg(:, 8) == 2), :);


m = size(features_sim_reg, 1);
n = size(features_sim_reg, 2);

fraction = 1;

rng(1);
rand_ind = randperm(m);
features_sim_reg = features_sim_reg(rand_ind, :);
delays = delays(rand_ind);

new_m = floor(size(features_sim_reg, 1) / fraction);
n = size(features_sim_reg, 2);

features_sim_reg = features_sim_reg(1:new_m, :);
delays = delays(1:new_m);

%normalize
%features_sim_reg  = features_sim_reg ./ max(features_sim_reg);
%delays = delays ./ max(delays);

% 90 10

train_features_sim_reg = features_sim_reg(1 : 1*new_m, :);
%dev_features_sim_reg = features_sim_reg(0.7*new_m+1 : 0.85*new_m, :);
%test_features_sim_reg = features_sim_reg(0.9*new_m+1 : new_m, :);

train_delays_sim_reg = delays(1 : 1*new_m);
%dev_delays_sim_reg = delays(0.7*new_m+1 : 0.85*new_m);
%test_delays_sim_reg = delays(0.*new_m+1 : new_m);

csvwrite('NEW2_train_features_sim_reg.csv',train_features_sim_reg);
%csvwrite('dev_features_sim_reg.csv',dev_features_sim_reg);
%csvwrite('NEW_test_features_sim_reg.csv',test_features_sim_reg);
csvwrite('NEW2_train_delays_sim_reg.csv',train_delays_sim_reg);
%csvwrite('dev_delays_sim_reg.csv',dev_delays_sim_reg);
%csvwrite('NEW_test_delays_sim_reg.csv',test_delays_sim_reg);


