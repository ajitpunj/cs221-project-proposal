clear variables; clc;

%train%
train_results = csvread('train_results_huge.csv');
train_actual = csvread('train_delays.csv');

n = size(train_results, 1);

train_actual = train_actual(1:107009, :);


mse_train = sum((train_results - train_actual).^2) / n;

signs_train = sum (sign(train_results) - sign(train_actual));

figure(1);
title('train'); xlabel('target'); ylabel('prediction');
hold on;
scatter(train_actual, train_results);
fplot(@(x) x, [-0.5 1.5])
hold off;

[r_train, m_train, b_train] = regression(train_actual', train_results');





%test%
test_results = csvread('test_results_huge.csv');
test_actual = csvread('test_delays.csv');

n = size(test_results, 1);

mse_test = sum((test_results - test_actual).^2) / n;

signs_test = sum (sign(test_results) - sign(test_actual));

figure(2);
title('test'); xlabel('target'); ylabel('prediction');
hold on;
scatter(test_actual, test_results);
fplot(@(x) x, [-0.5 0.5]);
hold off;

[r_test, m_test, b_test] = regression(test_actual', test_results');




