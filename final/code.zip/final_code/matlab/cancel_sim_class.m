clear variables; clc;

features = csvread('five_airlines_features.csv');
cancels = csvread('five_airlines_cancels.csv'); 
index_not_nan = not(isnan(cancels));

features = features(index_not_nan, :);
cancels = cancels(index_not_nan);



features_sim_reg = [features cancels];


m = size(features_sim_reg, 1);
n = size(features_sim_reg, 2);

fraction = 1;

rng(1);
rand_ind = randperm(m);
features_sim_reg = features_sim_reg(rand_ind, :);
cancels = cancels(rand_ind);

new_m = floor(size(features_sim_reg, 1) / fraction);
n = size(features_sim_reg, 2);

features_sim_reg = features_sim_reg(1:new_m, :);
cancels = cancels(1:new_m);

%normalize
%features_sim_reg  = features_sim_reg ./ max(features_sim_reg);
%delays = delays ./ max(delays);

% 90 10

train_features_sim_class_cancel = features_sim_reg(1 : 1*new_m, :);
%dev_features_sim_reg = features_sim_reg(0.7*new_m+1 : 0.85*new_m, :);
%test_features_sim_class_cancel = features_sim_reg(0.9*new_m+1 : new_m, :);

train_cancels_sim_class = cancels(1 : 1*new_m);
%dev_delays_sim_reg = delays(0.7*new_m+1 : 0.85*new_m);
%test_cancels_sim_class = cancels(0.*new_m+1 : new_m);


csvwrite('train_features_sim_class_cancel.csv',train_features_sim_class_cancel);
%csvwrite('dev_features_sim_reg.csv',dev_features_sim_reg);
%csvwrite('test_features_sim_class_cancel.csv',test_features_sim_class_cancel);
csvwrite('train_cancels_sim_class.csv',train_cancels_sim_class);
%csvwrite('dev_delays_sim_reg.csv',dev_delays_sim_reg);
%csvwrite('test_cancels_sim_class.csv',test_cancels_sim_class);


